package picker

type Value struct {
	Val       string
	IsNull    bool
	isSetNull bool
}
