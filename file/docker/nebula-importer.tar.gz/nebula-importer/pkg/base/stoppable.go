package base

type Stoppable interface {
	Stop()
}
