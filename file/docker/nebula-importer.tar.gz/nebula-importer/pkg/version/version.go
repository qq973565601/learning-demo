package version

var GitHash string
var GoVersion string
var Tag string
