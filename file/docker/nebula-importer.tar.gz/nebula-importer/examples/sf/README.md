# Examples for LDBC Social Network

You need to download the ldbc file first.
